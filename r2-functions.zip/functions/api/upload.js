export async function onRequestPost({ request, env }) {
  const formData = await request.formData();
  const files = formData.getAll('file');
  const uploaded = [];
  for (const file of files) {
    const key = Date.now() + '-' + file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    await env.MY_BUCKET.put(key, file.stream(), {
      httpMetadata: { contentType: file.type || 'application/octet-stream' }
    });
    uploaded.push({ name: file.name, key, size: file.size, url: '/api/media/' + key });
  }
  return Response.json({ ok: true, files: uploaded });
}

export async function onRequestGet({ env }) {
  const list = await env.MY_BUCKET.list();
  return Response.json({ ok: true, count: list.objects.length, objects: list.objects });
}